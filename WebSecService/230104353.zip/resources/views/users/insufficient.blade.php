@extends('layouts.master')

@section('content')
<div class="d-flex justify-content-center align-items-center" style="height: 80vh;">
    <h2 class="text-danger">Insufficient Credit</h2>
</div>
@endsection
